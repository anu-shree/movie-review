var Movie = require("../models/Movie.js");
exports.create = function(req , res){
    var movie = new Movie.MovieModel({
        FirstName : req.body.FirstName,
        LastName : req.body.LastName,
        Email : req.body.Email,
        Rating : req.body.Rating,
        Review : req.body.Review,
        MovieName : req.body.MovieName
    }).save(function(err , book){
        if(err)
            res.status(500).send(err.message);
        res.json(movie);
    });
};
exports.readOne = function (req , res){
    if(req.params.id === undefined)
        return res.status(400).send({});
    Movie.MovieModel.findOne({ _id : req.params.id} , function(err){
        if(err)
            return res.status(500).send(err.message);
        return res.json(movie);
    });
};
exports.readAll = function (req , res){
    Movie.MovieModel.find(function(err , movies){
        if(err)
            return res.status(500).send(500).send(err.message);
        return res.json(movies);
    });
};
exports.update = function (req , res){
    if(req.params.id === undefined)
        return res.status(400).send({});
    Movie.MovieModel.findById(req.params.id , function(err , movie){
        if(err){
            return res.status(500).send(err.message);
        }
        if(req.body.FirstName !== undefined)
            movie.FirstName = req.body.FirstName;
        if(req.body.LastName !== undefined)
            movie.LastName = req.body.LastName;
        if(req.body.Email !== undefined)
            movie.Email = req.body.Email;
        if(req.body.Rating !== undefined)
            movie.Rating = req.body.Rating;
        if(req.body.Review !== undefined)
            movie.Review = req.body.Review;
        if(req.body.MovieName !== undefined)
            movie.MovieName = req.body.MovieName;
        movie.save(function(err){
            if(err){
                return res.status(500).send(err.message);
            }
            else
                return res.json(movie);
        });
    });

};
exports.delete = function(req , res){
    if(req.params.id === undefined)
        return res.status(400).send({});
    Movie.MovieModel.findById(req.params.id , function(err , movie){
        if(err){
            return res.status(500).send(err.message);
        }
        movie.remove(function(err){
            if(err)
                return res.send(500 , err.message);
            res.status(200).send({});
        })
    });
};

