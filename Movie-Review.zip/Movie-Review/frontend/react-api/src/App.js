import React, { Component } from 'react';
import Movies from './components/movies';
class App extends Component {
  state = {
    movies: []
  }
  componentDidMount() {
    fetch('http://localhost:5000/movie/')
    .then(res => res.json())
    .then((data) => {
      this.setState({ contacts: data })
    })
    .catch(console.log)
  }
  render() {
    return (
      <Movies movies={this.state.movies} />
    );
  }
}

export default App;