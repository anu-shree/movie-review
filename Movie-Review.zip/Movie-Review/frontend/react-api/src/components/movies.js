import React from 'react'

    const Movies = ({ movies }) => {
      return (
        <div>
          <center><h1>Movies List</h1></center>
          {Movies.map((movie) => (
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">{movie.FirstName}</h5>
                <h6 class="card-subtitle mb-2 text-muted">{movie.Lastname}</h6>
                <p class="card-text">{movie.Email}</p>
              </div>
            </div>
          ))}
        </div>
      )
    };

    export default Movies