var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var methodOverride = require("method-override");
var mongoose = require("mongoose");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : false}));
app.use(methodOverride());
app.get("/" , function(req , res){
    res.send({title : "Hello World !"});
});
mongoose.connect("mongodb://localhost/movies");
var MoviesController = require("./controllers/MoviesController");
app.post("/movie" , MoviesController.create);
app.get("/movie/:id" , MoviesController.readOne);
app.get("/movie/" , MoviesController.readAll);
app.put("/movie/:id" , MoviesController.update);
app.delete("/movie/:id" , MoviesController.delete);
app.listen(5000 , function(){
    console.log("Listening on 5000");
});
//First Name
//Last name
//Email
//Rating
//Review
//Movie-Name
