/**
 * Model file for Movie
 */
var mongoose = require("mongoose");
var MovieSchema = new mongoose.Schema({
    FirstName : {type : String, required : true},
    LastName : {type : String , required : true},
    Email : {type : String , required : true},
    Rating : {type : Number , required : true},
    Review : {type : String , required : true},
    MovieName : {type : String , required : true}
});
var Movie = mongoose.model("movies" , MovieSchema);
module.exports = {MovieModel : Movie};
